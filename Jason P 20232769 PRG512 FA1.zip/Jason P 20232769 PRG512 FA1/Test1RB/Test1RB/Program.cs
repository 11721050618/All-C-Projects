﻿using System;

namespace RentOrBuy
{
    internal class Program
    {
        //error handling code to ensure the user enters a valid interger input.
        private static int GetValidInput(string message)
        {
            int value;
            Console.WriteLine(message);
            //it uses a while loop to check through the users input to make sure its an interger by using the TryParse method
            while (!int.TryParse(Console.ReadLine(), out value))
            {
                Console.WriteLine("Please enter a valid numeric amount.");
            }

            return value;
        }
        //error controle code to make the the user can enters double
        private static double GetValidDoubleInput(string message)
        {
            double value;
            Console.WriteLine(message);
            //this while loops through the users input until the user inputs a double, still part of error controle
            while (!double.TryParse(Console.ReadLine(), out value))
            {
                Console.WriteLine("Please enter a valid numeric amount.");
            }

            return value;
        }
        //Calculates the monthly loan repayment
        private static double CalculateMonthlyRepayment(double housePrice, double intrestRate, int timePeriod, int deposit)
        { 
            //already calculates the peroid in months and turns the precentage interest to a decimal
            double intrestRate2 = intrestRate / 12;
            float timePeriod2 = timePeriod * 12;
            double principal = housePrice - deposit;

            //calculates monthly loan repayment here
            return (principal * intrestRate2) / (1 - Math.Pow(1 + intrestRate2, -timePeriod2));
        }

        static void Main(string[] args)
        {
            // User inputs for their incomes with error control
            int grossMonthly = GetValidInput("Enter your gross monthly income before deductions: ");
            int estimatedTax = GetValidInput("Enter your estimated monthly tax: ");
            int monthlyExpend = GetValidInput("Enter your monthly expenditures: ");

            //monthly deductions are calculated here
            int monthlyDeductions = grossMonthly - (estimatedTax + monthlyExpend);
            //a third of the gross monthly is calculated here
            int thirdOfGrossMonthly = monthlyDeductions * 33 / 100;

            double housePrice, intrestRate;
            int timePeriod, deposit;
            double monthlyRepayment = 0;

            //user inputs wether they want to buy or rent a property and is given the option to exit the program
            Console.WriteLine("Do you want to 'buy' or 'rent'? Enter 'exit' to quit the program.");
            string buyOrRentOrExit = Console.ReadLine().ToLower();

            //using a while loop to do all the buying and renting calculation, if the while loop break the program ends
            //the while loop will only end when the user enters exit when prompted to make a choice
            while (buyOrRentOrExit != "exit")
            {
                if (buyOrRentOrExit == "buy")
                {
                    //here the user enters the values, GetValidDoubleInput class was declared in the begining of the code
                    //the GetValidDoubleInput ensures the users enters a valid double input(this can be a decimal input or int input)
                    //and GetValidInput ensures the user enters a valid interger value
                    housePrice = GetValidDoubleInput("Enter the purchase price: ");
                    intrestRate = GetValidDoubleInput("Enter the fixed interest rate (as a decimal): ");
                    timePeriod = GetValidInput("Enter the time period in years: ");
                    deposit = GetValidInput("Enter the deposit amount: ");

                    //CalcylateMonthlyRepayment class was declared in the beginning of the code and it
                    //calculates the monthly loan repayment for the user
                    monthlyRepayment = CalculateMonthlyRepayment(housePrice, intrestRate, timePeriod, deposit);

                    //the program prints out the users monthly loan repayment
                    Console.WriteLine("Your monthly loan repayment is: " + monthlyRepayment);

                    //the program checks if the users 1/3 gross income can afford the property
                    if (monthlyRepayment > thirdOfGrossMonthly)
                    {
                        Console.WriteLine("Accommodation affordability is unlikely.");
                    }
                    else
                    {
                        Console.WriteLine("Accommodation affordability is likely.");
                    }
                }
                //if the user enters rent then the programs promps the user to enter the following info
                else if (buyOrRentOrExit == "rent")
                {
                    int monthlyRent = GetValidInput("Enter your monthly rent payment: ");

                    //not sure if this was needed but I added it for safety
                    //the programs lets the user know if the rent they entered is more or less than 1/3 of their monthly income 
                    // and it will let the user know in a gentel way that its likely or unlikely
                    if (monthlyRent > thirdOfGrossMonthly)
                    {
                        Console.WriteLine("Accommodation affordability is unlikely.");
                    }
                    else
                    {
                        Console.WriteLine("Accommodation affordability is likely.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid option. Please enter 'buy', 'rent', or 'exit'.");
                }

                //the user is prompted a choice again if theyd like to redo their buying options or rental options
                Console.WriteLine("Do you want to 'buy' or 'rent'? Enter 'exit' to quit the program.");
                buyOrRentOrExit = Console.ReadLine().ToLower();
            }

            //once the user  inputs exit the programs exits
            if (buyOrRentOrExit == "exit")
            {
                Console.WriteLine("Exiting the program.");
            }
        }
    }
}
