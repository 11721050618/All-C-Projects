﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BusTicketingSystem4
{
    public partial class Form1 : Form
    {
        NewBookingForm bookingForm = new NewBookingForm();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.bookedTicketsTableAdapter.Fill(this.bussTicketDBDataSet.BookedTickets);
            LoadDataIntoDataGridView();
        }
        //encalsulated
        public abstract class Ticket
        {
            public int TicketID { get; set; }
            public string PassengerName { get; set; }
            public string Desitnation { get; set; }
            public DateTime DepatureDate { get; set; }
            public decimal TickerPrice { get; set; }

            public abstract void PrintTicketDetails();
        }
        //inheritance
        public class BusTicket : Ticket
        {
            public override void PrintTicketDetails()
            {
                //Program can be further enhanced by adding a Print Ticket action
            }
        }

        //loads data in the grid view by retrieving the data from the database by connecting using a connection string and later on
        //creating a query to retrieve the data 
        private void LoadDataIntoDataGridView()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM BookedTickets";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;

                        // Ensure DataGridView columns are correctly mapped
                        dataGridView1.Columns["TicketID"].DataPropertyName = "TicketID";
                        dataGridView1.Columns["PassengerName"].DataPropertyName = "PassengerName";
                        dataGridView1.Columns["Desitnation"].DataPropertyName = "Desitnation";
                        dataGridView1.Columns["DepatureDate"].DataPropertyName = "DepatureDate";
                        dataGridView1.Columns["TickerPrice"].DataPropertyName = "TickerPrice";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading data: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //gets the data of the cell the user clicked on
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                bookingForm.passengerNameTextBox.Text = row.Cells["PassengerName"].Value.ToString();
                bookingForm.desitnationTextBox.Text = row.Cells["Desitnation"].Value.ToString();
                bookingForm.dateTimePicker1.Value = Convert.ToDateTime(row.Cells["DepatureDate"].Value);
                bookingForm.ticketPriceTextBox.Text = row.Cells["TickerPrice"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //opens the new booking form
            NewBookingForm newBookingForm = new NewBookingForm();
            newBookingForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //updates the selected ticket
            if (dataGridView1.SelectedRows.Count > 0)
            {
                UpdateExistingEntry();
            }
            LoadDataIntoDataGridView();
        }

        private void UpdateExistingEntry()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                //creates a new ticket based on the entered values of the gridview
                BusTicket ticket = new BusTicket
                {
                    TicketID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["TicketID"].Value),
                    PassengerName = bookingForm.passengerNameTextBox.Text,
                    Desitnation = bookingForm.desitnationTextBox.Text,
                    DepatureDate = bookingForm.dateTimePicker1.Value,
                };
                //makes sure the user entered a decimal for the price
                if (decimal.TryParse(bookingForm.ticketPriceTextBox.Text, out decimal ticketPrice))
                {
                    ticket.TickerPrice = ticketPrice;
                }
                else
                {
                    MessageBox.Show("Invalid ticket price format. Please enter a valid decimal number.");
                    return;
                }
                //builds a query to update the edited ticket info
                string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "UPDATE BookedTickets SET PassengerName = @PassengerName, Destination = @Destination, DepartureDate = @DepartureDate, TicketPrice = @TicketPrice WHERE TicketID = @TicketID";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@TicketID", ticket.TicketID);
                            command.Parameters.AddWithValue("@PassengerName", ticket.PassengerName);
                            command.Parameters.AddWithValue("@Destination", ticket.Desitnation);
                            command.Parameters.AddWithValue("@DepartureDate", ticket.DepatureDate);
                            command.Parameters.AddWithValue("@TicketPrice", ticket.TickerPrice);

                            command.ExecuteNonQuery();
                            MessageBox.Show("Data updated successfully!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating data: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a ticket to update.");
            }
        }


        private void cancelBookingButton_Click(object sender, EventArgs e)
        {
            //cancels the selected ticket
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int ticketID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["TicketID"].Value);
                CancelTicket(ticketID);
                LoadDataIntoDataGridView();
            }
            else
            {
                MessageBox.Show("Please select a ticket to cancel.");
            }
        }

        private void CancelTicket(int ticketID)
        {
            //build the query to delete the selected ticket from the database
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "DELETE FROM BookedTickets WHERE TicketID = @TicketID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TicketID", ticketID);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Ticket canceled successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error canceling ticket: " + ex.Message);
                }
            }
        }
    }
}
