﻿namespace BusTicketingSystem4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ticketIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passengerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desitnationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.depatureDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tickerPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookedTicketsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bussTicketDBDataSet = new BusTicketingSystem4.BussTicketDBDataSet();
            this.bookedTicketsTableAdapter = new BusTicketingSystem4.BussTicketDBDataSetTableAdapters.BookedTicketsTableAdapter();
            this.newBookingButton = new System.Windows.Forms.Button();
            this.editBookingButton = new System.Windows.Forms.Button();
            this.cancelBookingButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookedTicketsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bussTicketDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ticketIDDataGridViewTextBoxColumn,
            this.passengerNameDataGridViewTextBoxColumn,
            this.desitnationDataGridViewTextBoxColumn,
            this.depatureDateDataGridViewTextBoxColumn,
            this.tickerPriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bookedTicketsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 96);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(839, 259);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ticketIDDataGridViewTextBoxColumn
            // 
            this.ticketIDDataGridViewTextBoxColumn.DataPropertyName = "TicketID";
            this.ticketIDDataGridViewTextBoxColumn.HeaderText = "Ticket ID";
            this.ticketIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.ticketIDDataGridViewTextBoxColumn.Name = "ticketIDDataGridViewTextBoxColumn";
            this.ticketIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // passengerNameDataGridViewTextBoxColumn
            // 
            this.passengerNameDataGridViewTextBoxColumn.DataPropertyName = "PassengerName";
            this.passengerNameDataGridViewTextBoxColumn.HeaderText = "Passenger Name";
            this.passengerNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.passengerNameDataGridViewTextBoxColumn.Name = "passengerNameDataGridViewTextBoxColumn";
            this.passengerNameDataGridViewTextBoxColumn.Width = 175;
            // 
            // desitnationDataGridViewTextBoxColumn
            // 
            this.desitnationDataGridViewTextBoxColumn.DataPropertyName = "Desitnation";
            this.desitnationDataGridViewTextBoxColumn.HeaderText = "Desitnation";
            this.desitnationDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.desitnationDataGridViewTextBoxColumn.Name = "desitnationDataGridViewTextBoxColumn";
            this.desitnationDataGridViewTextBoxColumn.Width = 150;
            // 
            // depatureDateDataGridViewTextBoxColumn
            // 
            this.depatureDateDataGridViewTextBoxColumn.DataPropertyName = "DepatureDate";
            this.depatureDateDataGridViewTextBoxColumn.HeaderText = "Depature Date";
            this.depatureDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.depatureDateDataGridViewTextBoxColumn.Name = "depatureDateDataGridViewTextBoxColumn";
            this.depatureDateDataGridViewTextBoxColumn.Width = 175;
            // 
            // tickerPriceDataGridViewTextBoxColumn
            // 
            this.tickerPriceDataGridViewTextBoxColumn.DataPropertyName = "TickerPrice";
            this.tickerPriceDataGridViewTextBoxColumn.HeaderText = "Ticker Price";
            this.tickerPriceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.tickerPriceDataGridViewTextBoxColumn.Name = "tickerPriceDataGridViewTextBoxColumn";
            this.tickerPriceDataGridViewTextBoxColumn.Width = 150;
            // 
            // bookedTicketsBindingSource
            // 
            this.bookedTicketsBindingSource.DataMember = "BookedTickets";
            this.bookedTicketsBindingSource.DataSource = this.bussTicketDBDataSet;
            // 
            // bussTicketDBDataSet
            // 
            this.bussTicketDBDataSet.DataSetName = "BussTicketDBDataSet";
            this.bussTicketDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookedTicketsTableAdapter
            // 
            this.bookedTicketsTableAdapter.ClearBeforeFill = true;
            // 
            // newBookingButton
            // 
            this.newBookingButton.Location = new System.Drawing.Point(38, 361);
            this.newBookingButton.Name = "newBookingButton";
            this.newBookingButton.Size = new System.Drawing.Size(113, 43);
            this.newBookingButton.TabIndex = 1;
            this.newBookingButton.Text = "New Booking";
            this.newBookingButton.UseVisualStyleBackColor = true;
            this.newBookingButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // editBookingButton
            // 
            this.editBookingButton.Location = new System.Drawing.Point(180, 361);
            this.editBookingButton.Name = "editBookingButton";
            this.editBookingButton.Size = new System.Drawing.Size(111, 43);
            this.editBookingButton.TabIndex = 2;
            this.editBookingButton.Text = "Edit Booking";
            this.editBookingButton.UseVisualStyleBackColor = true;
            this.editBookingButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // cancelBookingButton
            // 
            this.cancelBookingButton.Location = new System.Drawing.Point(317, 361);
            this.cancelBookingButton.Name = "cancelBookingButton";
            this.cancelBookingButton.Size = new System.Drawing.Size(132, 43);
            this.cancelBookingButton.TabIndex = 3;
            this.cancelBookingButton.Text = "Cancel Booking";
            this.cancelBookingButton.UseVisualStyleBackColor = true;
            this.cancelBookingButton.Click += new System.EventHandler(this.cancelBookingButton_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(368, 41);
            this.label1.TabIndex = 4;
            this.label1.Text = "Bus Ticketing System";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 454);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancelBookingButton);
            this.Controls.Add(this.editBookingButton);
            this.Controls.Add(this.newBookingButton);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookedTicketsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bussTicketDBDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private BussTicketDBDataSet bussTicketDBDataSet;
        private System.Windows.Forms.BindingSource bookedTicketsBindingSource;
        private BussTicketDBDataSetTableAdapters.BookedTicketsTableAdapter bookedTicketsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ticketIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passengerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desitnationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn depatureDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tickerPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button newBookingButton;
        private System.Windows.Forms.Button editBookingButton;
        private System.Windows.Forms.Button cancelBookingButton;
        private System.Windows.Forms.Label label1;
    }
}

