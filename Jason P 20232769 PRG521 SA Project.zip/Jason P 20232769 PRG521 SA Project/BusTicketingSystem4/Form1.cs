﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusTicketingSystem4
{
    
    public partial class Form1 : Form
    {
        NewBookingForm bookingForm = new NewBookingForm();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            this.bookedTicketsTableAdapter.Fill(this.bussTicketDBDataSet.BookedTickets);
            LoadDataIntoDataGridView();

        }

        private void LoadDataIntoDataGridView()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM BookedTickets";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading data: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                bookingForm.passengerNameTextBox.Text = row.Cells["PassengerName"].Value.ToString();
                bookingForm.desitnationTextBox.Text = row.Cells["Desitnation"].Value.ToString();
                bookingForm.dateTimePicker1.Value = Convert.ToDateTime(row.Cells["DepartureDate"].Value);
                bookingForm.dateTimePicker1.Text = row.Cells["TicketPrice"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewBookingForm newBookingForm = new NewBookingForm();
            newBookingForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                UpdateExistingEntry();
            }
            LoadDataIntoDataGridView();
        }

        private void UpdateExistingEntry()
        {
            int ticketID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ticketID"].Value);

            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "UPDATE BookedTickets SET PassengerName = @PassengerName, Desitnation = @Desitnation, DepatureDate = @DepatureDate, TickerPrice = @TickerPrice WHERE TicketID = @TicketID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TicketID", ticketID);
                        command.Parameters.AddWithValue("@PassengerName", bookingForm.passengerNameTextBox.Text);
                        command.Parameters.AddWithValue("@Desitnation", bookingForm.desitnationTextBox.Text);
                        command.Parameters.AddWithValue("@DepatureDate", bookingForm.dateTimePicker1.Value);
                        command.Parameters.AddWithValue("@TickerPrice", decimal.Parse(bookingForm.ticketPriceTextBox.Text));

                        command.ExecuteNonQuery();
                        MessageBox.Show("Data updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating data: " + ex.Message);
                }
            }
        }

        private void cancelBookingButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int passengerID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ticketID"].Value);
                CancelTicket(passengerID);
                LoadDataIntoDataGridView();
            }
            else
            {
                MessageBox.Show("Please select a ticket to cancel.");
            }
        }

        private void CancelTicket(int TicketID)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "DELETE FROM BookedTickets WHERE TicketID = @TicketID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TicketID", TicketID);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Ticket canceled successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error canceling ticket: " + ex.Message);
                }
            }
        }
    }
}
