﻿namespace BusTicketingSystem4
{
    partial class NewBookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PassengerName = new System.Windows.Forms.Label();
            this.Desitnation = new System.Windows.Forms.Label();
            this.DepatureDate = new System.Windows.Forms.Label();
            this.TicketPrice = new System.Windows.Forms.Label();
            this.passengerNameTextBox = new System.Windows.Forms.TextBox();
            this.desitnationTextBox = new System.Windows.Forms.TextBox();
            this.ticketPriceTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.ticketID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // PassengerName
            // 
            this.PassengerName.AutoSize = true;
            this.PassengerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassengerName.Location = new System.Drawing.Point(32, 104);
            this.PassengerName.Name = "PassengerName";
            this.PassengerName.Size = new System.Drawing.Size(200, 29);
            this.PassengerName.TabIndex = 0;
            this.PassengerName.Text = "Passenger Name";
            this.PassengerName.Click += new System.EventHandler(this.PassengerName_Click);
            // 
            // Desitnation
            // 
            this.Desitnation.AutoSize = true;
            this.Desitnation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Desitnation.Location = new System.Drawing.Point(32, 136);
            this.Desitnation.Name = "Desitnation";
            this.Desitnation.Size = new System.Drawing.Size(133, 29);
            this.Desitnation.TabIndex = 1;
            this.Desitnation.Text = "Desitnation";
            // 
            // DepatureDate
            // 
            this.DepatureDate.AutoSize = true;
            this.DepatureDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepatureDate.Location = new System.Drawing.Point(32, 170);
            this.DepatureDate.Name = "DepatureDate";
            this.DepatureDate.Size = new System.Drawing.Size(168, 29);
            this.DepatureDate.TabIndex = 2;
            this.DepatureDate.Text = "Depature Date";
            this.DepatureDate.Click += new System.EventHandler(this.label3_Click);
            // 
            // TicketPrice
            // 
            this.TicketPrice.AutoSize = true;
            this.TicketPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TicketPrice.Location = new System.Drawing.Point(32, 200);
            this.TicketPrice.Name = "TicketPrice";
            this.TicketPrice.Size = new System.Drawing.Size(141, 29);
            this.TicketPrice.TabIndex = 3;
            this.TicketPrice.Text = "Ticket Price";
            // 
            // passengerNameTextBox
            // 
            this.passengerNameTextBox.Location = new System.Drawing.Point(251, 108);
            this.passengerNameTextBox.Name = "passengerNameTextBox";
            this.passengerNameTextBox.Size = new System.Drawing.Size(240, 26);
            this.passengerNameTextBox.TabIndex = 4;
            // 
            // desitnationTextBox
            // 
            this.desitnationTextBox.Location = new System.Drawing.Point(251, 140);
            this.desitnationTextBox.Name = "desitnationTextBox";
            this.desitnationTextBox.Size = new System.Drawing.Size(240, 26);
            this.desitnationTextBox.TabIndex = 5;
            // 
            // ticketPriceTextBox
            // 
            this.ticketPriceTextBox.Location = new System.Drawing.Point(251, 204);
            this.ticketPriceTextBox.Name = "ticketPriceTextBox";
            this.ticketPriceTextBox.Size = new System.Drawing.Size(240, 26);
            this.ticketPriceTextBox.TabIndex = 7;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(298, 236);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(149, 36);
            this.submitButton.TabIndex = 8;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(251, 172);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(240, 26);
            this.dateTimePicker1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 29);
            this.label1.TabIndex = 10;
            this.label1.Text = "Ticket ID";
            // 
            // ticketID
            // 
            this.ticketID.Location = new System.Drawing.Point(251, 76);
            this.ticketID.Name = "ticketID";
            this.ticketID.Size = new System.Drawing.Size(240, 26);
            this.ticketID.TabIndex = 11;
            // 
            // NewBookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 284);
            this.Controls.Add(this.ticketID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.ticketPriceTextBox);
            this.Controls.Add(this.desitnationTextBox);
            this.Controls.Add(this.passengerNameTextBox);
            this.Controls.Add(this.TicketPrice);
            this.Controls.Add(this.DepatureDate);
            this.Controls.Add(this.Desitnation);
            this.Controls.Add(this.PassengerName);
            this.Name = "NewBookingForm";
            this.Text = "NewBookingForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PassengerName;
        private System.Windows.Forms.Label Desitnation;
        private System.Windows.Forms.Label DepatureDate;
        private System.Windows.Forms.Label TicketPrice;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox passengerNameTextBox;
        internal System.Windows.Forms.TextBox desitnationTextBox;
        internal System.Windows.Forms.TextBox ticketPriceTextBox;
        internal System.Windows.Forms.TextBox ticketID;
        internal System.Windows.Forms.DateTimePicker dateTimePicker1;
        internal System.Windows.Forms.Button submitButton;
    }
}