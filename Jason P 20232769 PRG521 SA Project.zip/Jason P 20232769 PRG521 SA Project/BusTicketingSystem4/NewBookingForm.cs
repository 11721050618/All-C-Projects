﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace BusTicketingSystem4
{
    public partial class NewBookingForm : Form
    {
        public NewBookingForm()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void PassengerName_Click(object sender, EventArgs e)
        {

        }

        public void submitButton_Click(object sender, EventArgs e)
        {
            //string connectionString = "Data Source = DESKTOP - BUGKGO7\\SQLEXPRESS; Initial Catalog = BussTicketDB; Integrated Security = True";
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO BookedTickets (TicketID, PassengerName, Desitnation, DepatureDate, TickerPrice) VALUES (@TicketID, @PassengerName, @Destination, @DepartureDate, @TickerPrice)";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    //cmd = new SqlCommand("insert into BookedTickets values('"+passengerNameTextBox+"','"+desitnationTextBox+"','"+ dateTimePicker1.Value.Date+ "','"+ticketPriceTextBox+"')", con);
                    cmd.Parameters.AddWithValue("@TicketID", ticketID.Text);
                    cmd.Parameters.AddWithValue("@PassengerName", passengerNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@Destination", desitnationTextBox.Text);
                    cmd.Parameters.AddWithValue("@DepartureDate", dateTimePicker1.Value);
                    cmd.Parameters.AddWithValue("@TickerPrice", decimal.Parse(ticketPriceTextBox.Text));

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Data saved successfully!");
                }
            }
        }
    }
}

